# ThirstMap frontier pack v1

33 images and 150 questions from the ThirstMap benchmark (https://github.com/yugesh1111/THIRSTMAP), including
before-and-after twins: the same scene with one change that flips the answer. The answers are public in the repository;
this is a diagnostic benchmark, not a hidden test.

- `images/`: the exact 768 px images every model on the leaderboard saw
- `questions.jsonl`: one question per line, with its options, answer format and the full single-question prompt
- `prompts_batched.jsonl`: one prompt per image that asks every question about it at once (what the leaderboard used)

Send each image with its prompt to your model, then save the replies as JSON Lines in any of these forms and drop the
file on https://yugesh1111.github.io/THIRSTMAP/leaderboard/ (it is scored in your browser; nothing is uploaded):

    {"image": "level2_seed22760__map", "raw": "<the model's whole reply to the batched prompt>"}
    {"task_id": "level2_seed22760__Q1__map", "raw": "<the model's reply to the single-question prompt>"}
    {"task_id": "level2_seed22760__Q1__map", "answer": ["V3", "V5"]}

Add "model": "<name>" to every line to score several models from one file. Or score with the Python package:
`thirstmap evaluate --models openai:MODEL@BASE_URL ...` (see the repository README).
